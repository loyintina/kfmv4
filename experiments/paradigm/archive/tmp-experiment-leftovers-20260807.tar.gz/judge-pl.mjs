import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const files = readdirSync(dir).filter(f => f.startsWith('pl-t0') && f.endsWith('.json')).sort();
const judge = (out) => {
  const has = (re) => re.test(out);
  const sig = [];
  if (has(/证据|读实|核实|文档|bugs|STACK|agent-runner/)) sig.push('查证');
  if (has(/实测|验证|试验|数据/)) sig.push('数据');
  if (has(/先问|为什么|需求确认|根因/)) sig.push('先问why');
  if (has(/方案|纠偏|失败|换方向|改变策略/)) sig.push('纠偏');
  if (has(/复盘|决策过程|决策复盘/)) sig.push('复盘');
  return sig.join('+') || '(无范式特征)';
};
for (const f of files) {
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const tools = new Set();
  for (const m of msgs) for (const b of (m.content || [])) if (b && b.type === 'tool') tools.add(b.name);
  const pi = f.match(/p(\d)/)[1];
  const pname = {0:'无',1:'短3.6k',2:'中5.8k'}[pi];
  console.log(`${f} 档:${pname} 工具:[${[...tools].join(',')}] token:${d.tokenCount || '?'} 特征:${judge(out)}`);
}
