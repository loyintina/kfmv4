import fs from 'node:fs';
const llm = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e13-llm.json', 'utf8'));
const script = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e13-script-e13.json', 'utf8'));
const trapOf = {};
for (const [id, a] of Object.entries(script.arms)) if (a.trap) trapOf[id] = { trap: a.trap, paradigm: a.paradigm };

// Mann-Whitney U（正态近似，n 够大时够用）
function mwu(x, y) {
  const all = [...x.map(v => ({ v, g: 0 })), ...y.map(v => ({ v, g: 1 }))].sort((a, b) => a.v - b.v);
  let rank = 1; const ranks = [];
  for (let i = 0; i < all.length; i++) {
    let j = i; while (j + 1 < all.length && all[j + 1].v === all[i].v) j++;
    const avg = (i + 1 + j + 1) / 2;
    for (let k = i; k <= j; k++) ranks[k] = avg;
    i = j;
  }
  let r0 = 0, n0 = x.length;
  all.forEach((e, i) => { if (e.g === 0) r0 += ranks[i]; });
  const u0 = r0 - n0 * (n0 + 1) / 2, n1 = y.length;
  const mu = n0 * n1 / 2, sigma = Math.sqrt(n0 * n1 * (n0 + n1 + 1) / 12);
  const z = (u0 - mu) / sigma;
  const phi = 0.5 * (1 + Math.sqrt(1 - Math.exp(-2 * z * z / Math.PI))); const p = 2 * (1 - phi);
  return { u0, z: z.toFixed(2), p: Math.min(1, p).toFixed(3) };
}

for (const trap of ['T1', 'T2', 'T3']) {
  console.log('=== ' + trap + '（n=32/组，跨模型合并；均值±粗差）===');
  for (const dim of ['meta_depth', 'self_dissection', 'boundary_awareness', 'reasoning_visible']) {
    const g = { '无': [], 'behavior-discipline': [] };
    for (const [id, meta] of Object.entries(trapOf)) {
      if (meta.trap !== trap) continue;
      const a = llm[id];
      if (a && a.score && typeof a.score[dim] === 'number') g[meta.paradigm].push(a.score[dim]);
    }
    const mean = arr => (arr.reduce((s, v) => s + v, 0) / arr.length).toFixed(2);
    const r = mwu(g['无'], g['behavior-discipline']);
    console.log(`${dim.padEnd(20)} 对照 ${mean(g['无'])} vs 纪律包 ${mean(g['behavior-discipline'])}  MWU z=${r.z} p=${r.p}`);
  }
}
