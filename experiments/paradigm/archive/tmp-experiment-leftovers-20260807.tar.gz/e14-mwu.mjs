import fs from 'node:fs';
const norm = k => k.toLowerCase().replace(/[-_]/g, '');
function mwu(x, y) {
  const all = [...x.map(v => ({ v, g: 0 })), ...y.map(v => ({ v, g: 1 }))].sort((a, b) => a.v - b.v);
  const ranks = [];
  for (let i = 0; i < all.length; i++) {
    let j = i; while (j + 1 < all.length && all[j + 1].v === all[i].v) j++;
    const avg = (i + 1 + j + 1) / 2;
    for (let k = i; k <= j; k++) ranks[k] = avg;
    i = j;
  }
  let r0 = 0;
  all.forEach((e, i) => { if (e.g === 0) r0 += ranks[i]; });
  const n0 = x.length, n1 = y.length;
  const u0 = r0 - n0 * (n0 + 1) / 2;
  const mu = n0 * n1 / 2, sigma = Math.sqrt(n0 * n1 * (n0 + n1 + 1) / 12);
  const z = (u0 - mu) / sigma;
  const phi = 0.5 * (1 + Math.sqrt(1 - Math.exp(-2 * z * z / Math.PI)));
  return { z: +z.toFixed(2), p: +Math.min(1, 2 * (1 - phi)).toFixed(3) };
}
const PARAS = ['无', 'behavior-discipline', 'metacognition', 'e14-bd-meta'];
const SHORT = { '无': '无包', 'behavior-discipline': 'bd', 'metacognition': 'meta', 'e14-bd-meta': 'bd+meta' };
const DIMS = ['meta_depth', 'self_dissection', 'boundary_awareness', 'reasoning_visible'];

// e14a: paradigm 从脚本归档 join
const scriptA = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e13-script-e14a.json', 'utf8')).arms;
const paraOf = {}; for (const [id, a] of Object.entries(scriptA)) paraOf[id] = a.paradigm;
const judgeA = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e14a.json', 'utf8'));
const cellsA = {}; for (const p of PARAS) { cellsA[p] = {}; for (const d of DIMS) cellsA[p][d] = []; }
for (const [id, a] of Object.entries(judgeA)) {
  const p = paraOf[id]; if (!p) continue;
  for (const d of DIMS) if (typeof a.score?.[d] === 'number') cellsA[p][d].push(a.score[d]);
}
console.log('--- e14a v2 MWU ---');
for (const [pa, pb] of [['无', 'behavior-discipline'], ['behavior-discipline', 'e14-bd-meta'], ['无', 'metacognition']]) {
  for (const d of ['meta_depth', 'reasoning_visible']) {
    const r = mwu(cellsA[pa][d], cellsA[pb][d]);
    console.log(`${d}: ${SHORT[pa]}(${(cellsA[pa][d].reduce((s,v)=>s+v,0)/cellsA[pa][d].length).toFixed(2)}) vs ${SHORT[pb]}(${(cellsA[pb][d].reduce((s,v)=>s+v,0)/cellsA[pb][d].length).toFixed(2)}) z=${r.z} p=${r.p}`);
  }
}
// e14b: pi 直读
const judgeB = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e14b.json', 'utf8'));
const cellsB = {}; for (const p of PARAS) { cellsB[p] = {}; for (const d of DIMS) cellsB[p][d] = []; }
for (const a of Object.values(judgeB)) {
  const p = PARAS[a.pi]; if (!p) continue;
  for (const d of DIMS) if (typeof a.score?.[d] === 'number') cellsB[p][d].push(a.score[d]);
}
console.log('--- e14b v2 MWU ---');
for (const [pa, pb] of [['无', 'behavior-discipline'], ['无', 'metacognition'], ['无', 'e14-bd-meta'], ['metacognition', 'e14-bd-meta'], ['behavior-discipline', 'e14-bd-meta']]) {
  for (const d of ['meta_depth', 'self_dissection']) {
    const r = mwu(cellsB[pa][d], cellsB[pb][d]);
    console.log(`${d}: ${SHORT[pa]}(${(cellsB[pa][d].reduce((s,v)=>s+v,0)/cellsB[pa][d].length).toFixed(2)}) vs ${SHORT[pb]}(${(cellsB[pb][d].reduce((s,v)=>s+v,0)/cellsB[pb][d].length).toFixed(2)}) z=${r.z} p=${r.p}`);
  }
}
