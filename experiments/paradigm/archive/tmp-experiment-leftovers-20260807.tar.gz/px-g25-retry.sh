#!/bin/bash
# px-g25 补跑 ×2（2026-08-05）：px-g25-4/5 死于教官空响应聚簇（重试已加牢 8 次退避）
cd /root/kfmv4
run() {
  node experiments/paradigm/tools/plugin-exam.mjs \
    --id "$1" --examiner-model "gemini-2.5-pro" --examiner-provider "聚光" \
    --examiner-role kfm-dev --pack metacognition \
    --scenario-file experiments/paradigm/scenarios/design-discussion.txt --turns 14
}
run px-g25-6 & run px-g25-7 & wait
echo G25-RETRY-DONE
