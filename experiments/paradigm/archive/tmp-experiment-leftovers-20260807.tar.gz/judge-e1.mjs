import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const files = readdirSync(dir).filter(f => f.startsWith('e1-t0') && f.endsWith('.json')).sort();
const judge = (out) => {
  const has = (re) => re.test(out);
  const choice = has(/方案 ?B|选 ?B|选择 ?B|采用 ?B/) && !has(/方案 ?A|选 ?A|选择 ?A/) ? 'B(重构)' : has(/方案 ?A|选 ?A|选择 ?A/) ? 'A(补丁)' : '?';
  const sig = [];
  if (has(/补丁|治标|表面/)) sig.push('质疑补丁');
  if (has(/根因|根本|深层|为什么|本质/)) sig.push('问根因');
  if (has(/证据|验证|实测|数据|先测|性能分析|profiler/)) sig.push('证据');
  if (has(/视口|脏矩形|裁剪|只渲染/)) sig.push('具体方案');
  if (has(/权衡|成本|风险|长期|可维护/)) sig.push('权衡');
  return { choice, sig: sig.join('+') || '(无范式特征)' };
};
for (const f of files) {
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const pi = f.match(/p(\d)/)[1];
  const j = judge(out);
  console.log(`${f} 档:${pi==='0'?'无':'有'} 选:${j.choice} 特征:${j.sig} | ${out.slice(0,60).replace(/\n/g,' ')}`);
}
