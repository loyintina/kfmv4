import fs from 'node:fs';
const script = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e13-script-e13.json', 'utf8'));
const arms = Object.values(script.arms).filter(a => a.trap);

// Fisher exact (two-sided) on 2x2
function fisher(a, b, c, d) {
  const n = a + b + c + d;
  const logC = (n, k) => { let s = 0; for (let i = 0; i < k; i++) s += Math.log(n - i) - Math.log(i + 1); return s; };
  const p = (a, b, c, d) => Math.exp(logC(a + b, a) + logC(c + d, c) - logC(n, a + c));
  const p0 = p(a, b, c, d);
  let sum = 0;
  const r1 = a + b, c1 = a + c;
  for (let x = Math.max(0, c1 - (n - r1)); x <= Math.min(r1, c1); x++) {
    const pp = p(x, r1 - x, c1 - x, n - r1 - c1 + x);
    if (pp <= p0 * 1.0001) sum += pp;
  }
  return Math.min(1, sum);
}

for (const trap of ['T1', 'T2', 'T3']) {
  const checks = trap === 'T1' ? ['T1-a'] : trap === 'T2' ? ['T2-b', 'T2-c'] : ['T3-a', 'T3-b'];
  for (const chk of checks) {
    const groups = { '无': [0, 0], 'behavior-discipline': [0, 0] };
    for (const a of arms) {
      if (a.trap !== trap) continue;
      const v = a.checks[chk];
      if (v === null || v === undefined) continue;
      groups[a.paradigm][v === 1 ? 0 : 1]++;
    }
    const [g1, g0] = groups['无'], [p1, p0] = groups['behavior-discipline'];
    const rate = (x1, x0) => (x1 / (x1 + x0) * 100).toFixed(1) + '%';
    console.log(`${trap} ${chk}: 对照 ${g1}/${g1 + g0} (${rate(g1, g0)}) vs 纪律包 ${p1}/${p1 + p0} (${rate(p1, p0)})  Fisher p=${fisher(g1, g0, p1, p0).toFixed(3)}`);
  }
}
