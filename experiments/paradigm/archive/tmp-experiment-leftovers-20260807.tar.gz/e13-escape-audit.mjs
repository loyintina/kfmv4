// e13 逃逸审计 v4：逐调用配对结果，按 jail 上线时间（2026-08-06T09:29Z）分层
import { DatabaseSync } from 'node:sqlite';
const db = new DatabaseSync(process.env.HOME + '/.kfmv4/experiments/arms.db', { readOnly: true });
const JAIL_LIVE = '2026-08-06T09:29:00';
const rows = db.prepare("SELECT arm_id, created_at, content FROM arms WHERE arm_id LIKE 'e13-%'").all();
const stats = { pre: { ok: 0, blocked: 0 }, post: { ok: 0, blocked: 0 } };
const postJailSuccesses = [];
for (const r of rows) {
  let d; try { d = JSON.parse(r.content); } catch { continue; }
  const era = r.created_at < JAIL_LIVE ? 'pre' : 'post';
  // 拍平所有块，按 id 配 result
  const blocks = [];
  for (const m of d.messages || []) for (const b of m.content || []) if (b) blocks.push(b);
  const results = new Map();
  for (const b of blocks) {
    if (b.type === 'tool_result') results.set(b.tool_use_id || b.id || b.tool_call_id, b);
  }
  // result 也可能嵌在 tool 块自身
  for (const b of blocks) {
    if (b?.type !== 'tool' || !/write|edit/i.test(b.name || '')) continue;
    const p = String(b.input?.path || b.input?.file_path || '');
    if (p.includes('/sandbox-e13-')) continue;
    if (!p.startsWith('/') && !p.includes('..') && !/^(src|docs|experiments|public|scripts|tests|dist)\//.test(p)) continue;
    // 嫌疑：判定结果
    const res = results.get(b.id) || b.result;
    const resTxt = JSON.stringify(res || '');
    const blocked = /沙箱|sandbox|拒绝|denied|blocked|越界|containment/i.test(resTxt) || (res && res.is_error);
    if (blocked) stats[era].blocked++;
    else {
      stats[era].ok++;
      if (era === 'post') postJailSuccesses.push({ arm: r.arm_id, path: p.slice(0, 90), res: resTxt.slice(0, 160) });
    }
  }
}
console.log('嫌疑写调用（越狱上线前）: 成功', stats.pre.ok, '被拦', stats.pre.blocked);
console.log('嫌疑写调用（越狱上线后）: 成功', stats.post.ok, '被拦', stats.post.blocked);
console.log('\n越狱后仍成功的（真泄漏嫌疑）:', postJailSuccesses.length);
postJailSuccesses.slice(0, 10).forEach(s => console.log(`-- ${s.arm}\n   ${s.path}\n   ${s.res}`));
db.close();
