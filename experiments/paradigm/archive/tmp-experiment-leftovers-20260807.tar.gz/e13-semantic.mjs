import fs from 'node:fs';
const llm = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e13-llm.json', 'utf8'));
const script = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e13-script-e13.json', 'utf8'));
const norm = k => k.toLowerCase().replace(/[-_]/g, '');
const trapOf = {};
for (const [id, a] of Object.entries(script.arms)) if (a.trap) trapOf[id] = a;

function fisher(a, b, c, d) {
  const n = a + b + c + d;
  const logC = (n, k) => { let s = 0; for (let i = 0; i < k; i++) s += Math.log(n - i) - Math.log(i + 1); return s; };
  const p = (a, b, c, d) => Math.exp(logC(a + b, a) + logC(c + d, c) - logC(n, a + c));
  const p0 = p(a, b, c, d);
  let sum = 0;
  const r1 = a + b, c1 = a + c;
  for (let x = Math.max(0, c1 - (n - r1)); x <= Math.min(r1, c1); x++) {
    const pp = p(x, r1 - x, c1 - x, n - r1 - c1 + x);
    if (pp <= p0 * 1.0001) sum += pp;
  }
  return Math.min(1, sum);
}

const ITEMS = { T1: ['t1b', 't1c', 't1d'], T2: ['t2d'], T3: ['t3c'] };
for (const [trap, keys] of Object.entries(ITEMS)) {
  for (const key of keys) {
    const g = { '无': [0, 0], 'behavior-discipline': [0, 0] };
    for (const [id, a] of Object.entries(llm)) {
      const meta = trapOf[id];
      if (!meta || meta.trap !== trap) continue;
      const sc = {};
      for (const [k, v] of Object.entries(a.score || {})) sc[norm(k)] = v;
      if (typeof sc[key] !== 'number') continue; // 缺键臂不进统计
      g[meta.paradigm][sc[key] === 1 ? 0 : 1]++;
    }
    const [c1, c0] = g['无'], [p1, p0] = g['behavior-discipline'];
    const cov = c1 + c0 + p1 + p0;
    console.log(`${trap} ${key}: 对照 ${c1}/${c1 + c0} vs 纪律包 ${p1}/${p1 + p0}  Fisher p=${fisher(c1, c0, p1, p0).toFixed(3)}（覆盖 ${cov}/64）`);
  }
}

// 覆盖率平衡检查：缺键是否偏组（偏则有选择偏差）
console.log('\n=== 覆盖率按组 ===');
for (const [trap, keys] of Object.entries(ITEMS)) {
  for (const p of ['无', 'behavior-discipline']) {
    let have = 0, total = 0;
    for (const [id, meta] of Object.entries(trapOf)) {
      if (meta.trap !== trap || meta.paradigm !== p) continue;
      total++;
      const a = llm[id];
      const sc = {};
      for (const [k, v] of Object.entries(a?.score || {})) sc[norm(k)] = v;
      if (keys.some(k => typeof sc[k] === 'number')) have++;
    }
    console.log(`${trap} ${p === '无' ? '对照' : '纪律包'}: ${have}/${total}`);
  }
}
