import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const metaRe = /我[的一直被]*(想|考虑|判断|排除|权衡|审视|监控|意识到|假设|评估|复盘|反思|思考|为什么|先)/g;
const MODELS = ['nano','mini','g25f','haiku'];
const files = readdirSync(dir).filter(f => f.startsWith('e6-t0p') && f.endsWith('.json')).sort();
const agg = {};
for (const f of files) {
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const pi = f.match(/p(\d)/)[1];
  const mi = parseInt(f.match(/m(\d)/)[1], 10);
  const key = `${MODELS[mi]}-${pi==='0'?'无':'有'}`;
  if (!agg[key]) agg[key] = [];
  agg[key].push((out.match(metaRe)||[]).length);
}
for (const mi of MODELS) {
  for (const pi of ['无','有']) {
    const v = agg[`${mi}-${pi}`] || [];
    if (!v.length) continue;
    const avg = (v.reduce((a,b)=>a+b,0)/v.length).toFixed(1);
    console.log(`${mi}-${pi}: 均值 ${avg} | ${v.join(',')} (${v.length}臂)`);
  }
  console.log();
}
