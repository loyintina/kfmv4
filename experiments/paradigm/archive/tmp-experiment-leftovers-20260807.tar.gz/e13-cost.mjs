import { DatabaseSync } from 'node:sqlite';
const db = new DatabaseSync(process.env.HOME + '/.kfmv4/experiments/arms.db', { readOnly: true });
const rows = db.prepare("SELECT arm_id, model, paradigm, content FROM arms WHERE arm_id LIKE 'e13-%'").all();
const PRICE = {
  'Qwen/Qwen3.6-35B-A3B': { in: 1.8, out: 10.8 },
  'Qwen/Qwen3.5-27B': { in: 0.6, out: 4.8 },
  'Pro/deepseek-ai/DeepSeek-V3': { in: 2, out: 8 },
  'Pro/MiniMaxAI/MiniMax-M2.5': { in: 2.1, out: 8.4 },
};
const PACK_TOK = { '无': 0, 'behavior-discipline': 8100, 'metacognition': 8100, 'e14-bd-meta': 16800 };
let total = 0; const perModel = {}; let outSum = 0;
for (const r of rows) {
  let out = 0;
  try { out = JSON.parse(r.content).tokenCount || 0; } catch {}
  const p = PRICE[r.model];
  if (!p) { console.log('未知模型:', r.model); continue; }
  const inTok = (PACK_TOK[r.paradigm] ?? 8100) + 500;
  const cost = (inTok * p.in + out * p.out) / 1e6;
  total += cost; outSum += out;
  perModel[r.model] = (perModel[r.model] || 0) + cost;
}
console.log('e13 臂数:', rows.length);
console.log('e13 估算总成本:', total.toFixed(2), '元');
for (const [m, c] of Object.entries(perModel)) console.log(' ', m + ':', c.toFixed(2), '元');
console.log('平均输出 token:', Math.round(outSum / rows.length));
