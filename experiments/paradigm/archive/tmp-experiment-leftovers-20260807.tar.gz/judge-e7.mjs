import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const metaRe = /我[的一直被]*(想|考虑|判断|排除|权衡|审视|监控|意识到|假设|评估|复盘|反思|思考|为什么|先)/g;
const PARADIGMS = ['无包', 'v1-8k', '32k', '48k', '64k', '96k'];
const MODELS = ['mm3', 'flash'];
// 臂 id: e7-t0p{pi}m{mi}r{n}
const agg = {}; // key = `${mi}-${pi}` -> {density[], len[]}
for (const f of readdirSync(dir)) {
  if (!f.startsWith('e7-t0') || !f.endsWith('.json')) continue;
  const m = f.match(/p(\d)m(\d)r(\d)/);
  if (!m) continue;
  const [, pi, mi] = m;
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const key = `${mi}-${pi}`;
  if (!agg[key]) agg[key] = [];
  agg[key].push({ den: (out.match(metaRe) || []).length, len: out.length });
}
console.log('=== 元认知密度（匹配次数/臂）===');
console.log('模型\\档 | ' + PARADIGMS.join(' | '));
for (let mi = 0; mi < MODELS.length; mi++) {
  const row = [MODELS[mi]];
  for (let pi = 0; pi < PARADIGMS.length; pi++) {
    const v = (agg[`${mi}-${pi}`] || []).map(x => x.den);
    row.push(v.length ? `${(v.reduce((a,b)=>a+b,0)/v.length).toFixed(1)} (${v.join(',')})` : '—');
  }
  console.log(row.join(' | '));
}
console.log('\n=== 输出长度（字符/臂）===');
for (let mi = 0; mi < MODELS.length; mi++) {
  const row = [MODELS[mi]];
  for (let pi = 0; pi < PARADIGMS.length; pi++) {
    const v = (agg[`${mi}-${pi}`] || []).map(x => x.len);
    row.push(v.length ? `${Math.round(v.reduce((a,b)=>a+b,0)/v.length)}` : '—');
  }
  console.log(row.join(' | '));
}
