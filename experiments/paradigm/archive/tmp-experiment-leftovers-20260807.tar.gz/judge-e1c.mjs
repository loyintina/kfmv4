import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const files = readdirSync(dir).filter(f => f.startsWith('e1c-t0') && f.endsWith('.json')).sort();
const judge = (out) => {
  const has = (re) => re.test(out);
  const rootCause = has(/根因|为什么|诊断|定位|先分析|先测量|先复现|先查|先问|profiler|性能剖析|瓶颈|测量|复现|证据/) ;
  const patch = has(/帧率限制|跳过|降频|节流|优化循环|减少.*帧|加.*限制|直接改|先加上|快速修复|立即可用|先做个|临时方案|快速方案|先处理/) ;
  const approach = rootCause ? (patch ? '根因+补丁' : '根因优先') : (patch ? '直接补丁' : '其他');
  const sig = [];
  if (rootCause) sig.push('问根因');
  if (patch) sig.push('补丁');
  if (has(/先.*为什么|再.*改哪里|先问/)) sig.push('范式语');
  return { approach, sig: sig.join('+') || '(无)' };
};
for (const f of files) {
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const pi = f.match(/p(\d)/)[1];
  const j = judge(out);
  console.log(`${f} 档:${pi==='0'?'无':'有'} 倾向:${j.approach} 特征:${j.sig} | ${out.slice(0,65).replace(/\n/g,' ')}`);
}
