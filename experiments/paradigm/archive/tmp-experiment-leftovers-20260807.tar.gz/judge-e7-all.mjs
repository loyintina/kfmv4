import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const metaRe = /我[的一直被]*(想|考虑|判断|排除|权衡|审视|监控|意识到|假设|评估|复盘|反思|思考|为什么|先)/g;
const PARADIGMS = ['无包', 'v1-8k', '32k', '48k', '64k', '96k'];
const PREFIXES = ['e7-t0', 'e7b-t0', 'e7c-t0'];
// 直接读 modelId 聚合（免映射表）
const agg = {}; // model -> pi -> [{den, len}]
for (const f of readdirSync(dir)) {
  if (!f.endsWith('.json')) continue;
  if (!PREFIXES.some(p => f.startsWith(p))) continue;
  const m = f.match(/p(\d)m(\d)r(\d)/);
  if (!m) continue;
  const pi = Number(m[1]);
  let d;
  try { d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8')); } catch { console.error(`[跳过坏文件] ${f}`); continue; }
  const model = d.modelId || 'unknown';
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  (agg[model] ??= {});
  (agg[model][pi] ??= []).push({ den: (out.match(metaRe) || []).length, len: out.length });
}
const models = Object.keys(agg).sort();
console.log('=== 元认知密度均值（每臂分布）===');
console.log('模型 | ' + PARADIGMS.join(' | '));
for (const model of models) {
  const row = [model];
  for (let pi = 0; pi < PARADIGMS.length; pi++) {
    const v = (agg[model][pi] || []).map(x => x.den);
    row.push(v.length ? `${(v.reduce((a,b)=>a+b,0)/v.length).toFixed(1)} (${v.join(',')})` : '—');
  }
  console.log(row.join(' | '));
}
console.log('\n=== 归一化密度（匹配数/千字符）===');
for (const model of models) {
  const row = [model];
  for (let pi = 0; pi < PARADIGMS.length; pi++) {
    const v = agg[model][pi] || [];
    if (!v.length) { row.push('—'); continue; }
    const d = v.reduce((a,b)=>a+b.den,0)/v.length, l = v.reduce((a,b)=>a+b.len,0)/v.length;
    row.push(l > 0 ? (d/(l/1000)).toFixed(2) : '—');
  }
  console.log(row.join(' | '));
}
