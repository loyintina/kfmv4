import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const MODELS = ['flash','mimo','mm25','mm27','mm3','k2.5','glm5','qwen35'];
const files = readdirSync(dir).filter(f => f.startsWith('e4-t0p') && f.endsWith('.json')).sort();
const judge = (out) => {
  const has = (re) => re.test(out);
  const rootCause = has(/根因|为什么|诊断|定位|先分析|先测量|先复现|先查|先问|profiler|瓶颈|测量|复现|证据|读.*代码|排查/) ;
  const patch = has(/帧率限制|跳过|降频|节流|优化循环|减少.*帧|加.*限制|直接改|先加上|快速|临时|立即可用|先做个/) ;
  if (rootCause && !patch) return '根因优先';
  if (rootCause && patch) return '根因+补丁';
  if (patch) return '直接补丁';
  return '其他';
};
// 按模型×档汇总
const agg = {};
for (const f of files) {
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const pi = f.match(/p(\d)/)[1];
  const mi = parseInt(f.match(/m(\d)/)[1], 10);
  const key = `${MODELS[mi]}-${pi==='0'?'无':'有'}`;
  if (!agg[key]) agg[key] = [];
  agg[key].push(judge(out));
}
for (const mi of MODELS) {
  for (const pi of ['无','有']) {
    const key = `${mi}-${pi}`;
    const v = agg[key] || [];
    const c = {};
    for (const x of v) c[x] = (c[x]||0)+1;
    console.log(`${key}: ${JSON.stringify(c)} (${v.length}臂)`);
  }
  console.log();
}
