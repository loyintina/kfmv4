import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const MODELS = ['flash','mimo','mm25','mm27','mm3','k2.5','glm5','qwen35'];
const files = readdirSync(dir).filter(f => f.startsWith('e5-t0p') && f.endsWith('.json')).sort();
const judge = (out) => {
  const has = (re) => re.test(out);
  const sig = [];
  if (has(/我的思考|我的思路|我先想|我的假设|我考虑|我排除|我为什么|我判断|我的优先级|我权衡|我意识到|我重新|我审视|我监控|我自己的判断标准|我是怎么想/)) sig.push('思考监控');
  if (has(/元认知|元思考|元层次|元视角|元/)) sig.push('元语言');
  if (has(/第一步|先.*再.*最后|步骤|流程/)) sig.push('结构化');
  if (has(/验证|证据|数据|风险|权衡|成本/)) sig.push('权衡');
  if (has(/我认为|我的结论|我的判断是/)) sig.push('自我判断');
  return sig.join('+') || '(无)';
};
// 量化：元认知显式化密度（「我」+思考动词）
const metaRe = /我[的一直被]*(想|考虑|判断|排除|权衡|审视|监控|意识到|假设|评估|复盘|反思|思考|为什么)/g;
const agg = {};
for (const f of files) {
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const pi = f.match(/p(\d)/)[1];
  const mi = parseInt(f.match(/m(\d)/)[1], 10);
  const key = `${MODELS[mi]}-${pi==='0'?'无':'有'}`;
  if (!agg[key]) agg[key] = { n: 0, meta: 0, judge: {} };
  agg[key].n++;
  const m = (out.match(metaRe) || []).length;
  agg[key].meta += m;
  const j = judge(out);
  agg[key].judge[j] = (agg[key].judge[j]||0)+1;
}
for (const mi of MODELS) {
  for (const pi of ['无','有']) {
    const key = `${mi}-${pi}`;
    const a = agg[key];
    if (!a) continue;
    console.log(`${key}: 元认知密度 ${(a.meta/a.n).toFixed(1)}/臂 | ${JSON.stringify(a.judge)} (${a.n}臂)`);
  }
  console.log();
}
