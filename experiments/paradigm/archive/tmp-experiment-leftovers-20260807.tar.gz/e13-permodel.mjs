import fs from 'node:fs';
const script = JSON.parse(fs.readFileSync('experiments/paradigm/meta-pool/judge-e13-script-e13.json', 'utf8'));
const arms = Object.values(script.arms).filter(a => a.trap);
const short = m => m.split('/').pop();
for (const [trap, chk] of [['T2', 'T2-b'], ['T3', 'T3-a']]) {
  console.log(`=== ${trap} ${chk} 逐模型 ===`);
  const models = [...new Set(arms.map(a => a.model))].sort();
  for (const m of models) {
    for (const p of ['无', 'behavior-discipline']) {
      const cell = arms.filter(a => a.trap === trap && a.model === m && a.paradigm === p);
      const hits = cell.filter(a => a.checks[chk] === 1).length;
      console.log(`  ${short(m).padEnd(16)} ${p === '无' ? '对照' : '纪律包'}: ${hits}/${cell.length}`);
    }
  }
}
