import { readFileSync, readdirSync } from 'fs';
const dir = '/root/.kfmv4/sessions/script';
const metaRe = /我[的一直被]*(想|考虑|判断|排除|权衡|审视|监控|意识到|假设|评估|复盘|反思|思考|为什么|先)/g;
// 只取 mm3（e5 的 m3 + e5b 全部）
const files = [];
for (const f of readdirSync(dir)) {
  if (!f.endsWith('.json')) continue;
  if (f.startsWith('e5-t0p3')) files.push(f);
  if (f.startsWith('e5b-t0p')) files.push(f);
}
const agg = {};
for (const f of files) {
  const d = JSON.parse(readFileSync(`${dir}/${f}`, 'utf-8'));
  const msgs = d.messages || [];
  let out = '';
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role !== 'ai') continue;
    const texts = (msgs[i].content || []).filter(b => b && b.type === 'text' && b.text).map(b => b.text);
    if (texts.length) { out = texts.join('\n'); break; }
  }
  const pi = f.match(/p(\d)/)[1];
  const key = pi==='0' ? '无包' : '有包';
  if (!agg[key]) agg[key] = [];
  agg[key].push((out.match(metaRe)||[]).length);
}
for (const [k, v] of Object.entries(agg)) {
  const avg = (v.reduce((a,b)=>a+b,0)/v.length).toFixed(1);
  console.log(`mm3 ${k}（${v.length} 臂）: 均值 ${avg} | 每臂 ${v.join(',')}`);
}
